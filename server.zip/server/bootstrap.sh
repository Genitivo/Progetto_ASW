##!/usr/bin/env bash

sudo su -c "yum install java-1.8.0-openjdk"
sudo yum install java-1.8.0-openjdk -y
sudo sh /vagrant/apache-tomee-jaxrs-1.7.4/bin/startup.sh


